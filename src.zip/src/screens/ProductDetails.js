/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React from 'react';

import {
  Text,
  View,
  Dimensions,
} from 'react-native';
const {width,height}=Dimensions.get("screen")
export default function ProductDetails() {
  return (
  <View >
   <Text>Product Details</Text>
  </View>
  );
}



