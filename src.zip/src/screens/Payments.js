/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React from 'react';

import {
  View,
  Dimensions,
} from 'react-native';
const {width,height}=Dimensions.get("screen")
export default function Payments() {
  return (
  <View >
   <Text>Payments</Text>
  </View>
  );
}



