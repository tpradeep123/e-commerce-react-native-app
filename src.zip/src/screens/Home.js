/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React from 'react';

import {
  Text,
  View,
  Dimensions,
} from 'react-native';
import CircleComponent from '../components/ui_compponents/CircleComponent/CircleComponent';
import InputText from '../components/ui_compponents/TextField/InputText';
import Banner from '../components/ui_compponents/Banner/Banner';
import FlottingCart from '../components/ui_compponents/FlottingCart/FlottingCart';
import Card from '../components/ui_compponents/Card/Card';
const {width,height}=Dimensions.get("screen")
export default function Home() {
  return (
  <View style={{backgroundColor:'#ecf0f1'}} >
 
  <CircleComponent/>
  <Banner/>
  <Card/>
  <FlottingCart/>
  </View>
  );
}



