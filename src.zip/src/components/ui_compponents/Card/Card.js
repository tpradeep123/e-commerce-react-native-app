import React from 'react';

import {Text, View, Dimensions,TextInput, Image} from 'react-native';
import Button from '../ButtonComponent/Button';
import MCI from 'react-native-vector-icons/MaterialCommunityIcons';
import { serverURL } from '../../../Services/FetchNodeServices';
import { FlatList, ScrollView } from "react-native-gesture-handler"
const {width, height} = Dimensions.get('screen');

export default function Card() {

  var data=[{productid:'1',productname:'Halidiram Hara Bhara kabab',weight:'500gm',rate:'300',offer:'185',productimage:'haldiram.png'},
  {productid:'2',productname:'Coca cola',weight:'500ml',rate:'100',offer:'90',productimage:'cocacola.png'},
  {productid:'2',productname:'Amul masti',weight:'100ml',rate:'50',offer:'30',productimage:'amulmasti.png'},
  {productid:'2',productname:'Tide detergent',weight:'500gm',rate:'100',offer:'85',productimage:'detergent.png'},
]

const ShowProduct=({item})=>{
  return(
    <View style={{ margin: 5, backgroundColor: '#fff',width: width * 0.38,height: 'auto',borderRadius:5,paddingBottom:10}}>
      <View style={{alignItems:'center'}}>
      <Image
      style={{resizeMode:'contain',width:100,height:100,marginTop:15,marginBottom:15}}
      source={{uri:`${serverURL}/images/${item.productimage}`}}/>
      </View>
      <View style={{paddingLeft:12}}>
      <Text style={{fontSize:12,fontWeight:'bold',letterSpacing:1,height:32}}>{item.productname}</Text>
      <Text style={{fontSize:10,paddingTop:5}}>{item.weight}</Text>
      </View>
      <View style={{paddingLeft:12,flexDirection:'row',justifyContent:'space-between',paddingTop:20}}>
      <View>
     <Text style={{fontSize:13,fontWeight:'bold'}}>&#8377;{item.offer}</Text>
     <Text style={{fontSize:10}}>&#8377;{item.rate}</Text>
     </View>
     <Button w={0.18} h={0.035} label={'ADD'} bgcolor={'white'} fontSize={15} textColor={'#008000'} borderColor={'#008000'} />
      </View>
      </View>
  )
}
  return (
    <ScrollView style={{padding:5,marginVertical:5}} showsHorizontalScrollIndicator={false} horizontal={true}>
    <FlatList
    horizontal
    data={data}
    renderItem={({item})=><ShowProduct item={item}/>}
    keyExtractor={item =>item.productid}
    />
    </ScrollView>
  );
}
