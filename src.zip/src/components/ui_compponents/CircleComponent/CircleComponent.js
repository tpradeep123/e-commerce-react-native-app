import {View,Dimensions,Image,Text} from "react-native"
import { serverURL } from "../../../Services/FetchNodeServices"
import { FlatList, ScrollView } from "react-native-gesture-handler"
const {width,height}=Dimensions.get("screen")
export default function CircleComponent(){
    var data=[{categoryid:'1',categoryname:'Drinks',categoryicon:'apple.jpg'},
    {categoryid:'2',categoryname:'Detergent',categoryicon:'aee0881e-6b89-458a-ab72-d9674b65a2e1.png'},
    {categoryid:'3',categoryname:'Milk & Bread',categoryicon:'0fb931f0-b7fe-4054-a7a5-7511f4bc6cc1.png'},
    {categoryid:'4',categoryname:'Cooking Oil',categoryicon:'edibleoil.png'},
    {categoryid:'5',categoryname:'Salt',categoryicon:'d50e03b7-6550-4331-84ca-ba6d391d9af6.png'},
    {categoryid:'6',categoryname:'Salt',categoryicon:'d50e03b7-6550-4331-84ca-ba6d391d9af6.png'}
]
var color=['#bdc3c7','#54a0ff','#00d2d3','#feca57','#badc58']
const ShowCategory=({item})=>{
    return(<View  style={{margin:5,flexDirection:'column',justifyContent:'center',alignItems:'center',width:120,height:135}}>
    <View style={{flexDirection:'column',justifyContent:'center',alignItems:'center',width:120,height:120,borderRadius:60,backgroundColor:color[parseInt(Math.random()*4)],}}>
     <Image style={{width:70,height:70,resizeMode:'contain'}} source={{uri:`${serverURL}/images/${item.categoryicon}`}}/>
    </View>
    <Text>{item.categoryname}</Text>
    </View>)
}
return(
    <ScrollView style={{padding:5,marginVertical:5}} showsHorizontalScrollIndicator={false} horizontal={true}>
    <FlatList
    horizontal
    data={data}
    renderItem={({item})=><ShowCategory item={item}/>}
    keyExtractor={item =>item.categoryid}
    />
    </ScrollView>
)  
    
}