/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React from 'react';

import {
  View,
  Dimensions,
  Text,
  Image
} from 'react-native';
import MI from "react-native-vector-icons/MaterialIcons"
const {width,height}=Dimensions.get("screen")
export default function FlottingCart() {
  return (
  <View style={{width:width*0.9,height:height*0.05,borderRadius:10, backgroundColor:'#006400',flexDirection:'row',justifyContent:'space-between',alignItems:'center',margin:20} }>
  <View style={{flexDirection:'row',padding:10}}>
      <Image
      style={{resizeMode:'contain',width:25,height:25}}
      source={require('../../../../assets/food.png')}/>
      
      <View style={{flexDirection:'column',paddingLeft:5}}>
      <Text style={{fontSize:8,color:"#fff"}}>3 items</Text>
      <Text style={{fontSize:12,color:"#fff",fontWeight:'bold'}}>&#8377;86</Text>
      </View>
      </View>
      <View style={{padding:6,flexDirection:'row'}}>
        <Text style={{fontSize:12,color:"#fff",fontWeight:'bold'}}>View Cart</Text>
       <MI style={{marginTop:3,color:"#fff",fontWeight:'bold'}} name={"arrow-right"} fontSize={25}/>
      </View>
      </View>
     
 
  );
}



